# -*- coding: utf-8 -*-

import sys
import os
import requests
import datetime
import json


def get_time():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def add_log(text):
    with open(os.path.join('..', 'output', '_log.txt'), mode='a') as f:
        f.write('[' + get_time() + ']' + text + '\n')
    print(text)


def req_api(input_file, API_TOKEN, USERNAME, PROJECT_ID, MODEL_ID):
    # Set HTTP headers
    # Note: The charset should match the contents of the file.
    headers = {'Content-Type': 'text/plain; charset=UTF-8'}
    
    data = open(input_file, 'rb').read()
    
    # Make predictions on your data
    # The URL has the following format:
    #     https://suuchikaiseki2.vision.hq.west.ntt.co.jp/predApi/v1.0/<PROJECT_ID>/<MODEL_ID>/predict
    # See docs for details:
    #     suuchikaiseki1.vision.hq.west.ntt.co.jp/docs-jp/users-guide/deploy/api/new-prediction-api.html
    predictions_response = requests.post('https://suuchikaiseki2.vision.hq.west.ntt.co.jp/predApi/v1.0/%s/%s/predict' % (PROJECT_ID, MODEL_ID),
                                         auth=(USERNAME, API_TOKEN), data=data, headers=headers,verify=False)
    
    predictions_response.raise_for_status()
    return predictions_response.json()


def main():
    try:
        conf = json.load(open(os.path.join('..', 'config.json')))
        add_log("JSON定義ファイルの読み込み完了")
    except json.JSONDecodeError as e:
        add_log("JSON定義ファイルの読み込み失敗")
        exit()
    
    all_req_cnt = 0                        # リクエスト数の合計
    finish_req_cnt = 0                     # リクエスト実行済の合計
    failed_req_cnt = 0                     # リクエスト失敗の合計
    
    for i in conf['setting']:
        all_req_cnt = all_req_cnt + len(i['data_info'])
    add_log(str(all_req_cnt) + "件のリクエストを開始")
    
    for i in conf['setting']:
        API_TOKEN = i['api_info']['API_TOKEN']
        USERNAME = i['api_info']['USERNAME']
        PROJECT_ID = i['api_info']['PROJECT_ID']
        MODEL_ID = i['api_info']['MODEL_ID']
        
        for j in i['data_info']:
            input_file = os.path.join('..', 'input', j['input_file_name'])
            if j['output_file_name'] == '':
                output_file = os.path.join('..', 'output', os.path.splitext(j['input_file_name'])[0] + '.json')
            else:
                output_file = os.path.join('..', 'output', j['output_file_name'])
            
            finish_req_cnt = finish_req_cnt + 1
            try:
                output = req_api(input_file, API_TOKEN, USERNAME, PROJECT_ID, MODEL_ID)
                with open(output_file, 'w') as fp:
                    json.dump(output, fp, indent=4, ensure_ascii=False)
                add_log(str(finish_req_cnt) +  "/" +  str(all_req_cnt) + "件の結合を完了 （うち" + str(failed_req_cnt) +"件失敗）")
            except requests.exceptions.RequestException as e:
                failed_req_cnt = failed_req_cnt + 1
                add_log("予測結果の取得に失敗 PROJECT_ID:" + PROJECT_ID + ", MODEL_ID:" + MODEL_ID)
                add_log(str(finish_req_cnt) +  "/" +  str(all_req_cnt) + "件の結合を完了 （うち" + str(failed_req_cnt) +"件失敗）")


if __name__ == '__main__':
    main()

