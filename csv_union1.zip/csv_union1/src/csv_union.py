# -*- coding: utf-8 -*-

########################
# 
# ver.：1.10
# 
########################

import os
import datetime
import json
import pandas as pd


def main():
    
    conf = json.load(open(os.path.join('..', 'config.json')))
    
    for i in conf['setting']:
        df_wk=[]
        input_file=[]
        for j in i['input_file']['file_name']:
            df_wk = df_wk + [pd.read_csv(os.path.join('..', 'input', j), sep=',', encoding='utf-8', engine='python', dtype=str, na_filter=False)]
    
        df0 = pd.concat(df_wk)
    
        df0.to_csv(os.path.join('..', 'output', i['output_file']['file_name']), index=False)
        with open(os.path.join('..', 'output', 'result_' + i['output_file']['file_name'] + '.txt'), mode='w') as f:
            f.write(i['output_file']['file_name'] + 'の情報\n\n')
            f.write('  ●処理日時：' + str(datetime.datetime.now().strftime('%Y/%m/%d %H:%M:%S')) + '\n\n')
            f.write('  ●レコード数：' + str(len(df0)) + '\n\n')
            f.write('  ●結合ファイル：' + i['input_file']['file_name'][0] + '\n')
            for j in i['input_file']['file_name'][1:]:
                f.write('                  ' + j + '\n')
            f.write('\n')
            f.write('  ●結合条件：UNION ALL\n\n')


if __name__ == '__main__':
    main()
    