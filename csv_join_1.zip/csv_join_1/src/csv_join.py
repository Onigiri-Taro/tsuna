# -*- coding: utf-8 -*-

########################
# 
# ver.：1.20
# 
########################

import os
import datetime
import json
import pandas as pd


def get_time():
    return datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def add_log(text):
    with open(os.path.join('..', 'output', '_log.txt'), mode='a') as f:
        f.write('[' + get_time() + ']' + text + '\n')
    print(text)


def main():
    try:
        conf = json.load(open(os.path.join('..', 'config.json')))
        add_log("JSON定義ファイルの読み込み完了")
    except json.JSONDecodeError as e:
        add_log("JSON定義ファイルの読み込み失敗")
        exit()
    
    all_join_cnt = len(conf['setting'])   # 結合数の合計
    finish_join_cnt = 0                   # 結合数済の合計
    add_log(str(all_join_cnt) + "件の結合を開始")
    
    for i in conf['setting']:
        df1 = pd.read_csv(os.path.join('..', 'input', i['input_file']['file_name1']), sep=',', encoding='utf-8', engine='python', dtype=str, na_filter=False)
        df2 = pd.read_csv(os.path.join('..', 'input', i['input_file']['file_name2']), sep=',', encoding='utf-8', engine='python', dtype=str, na_filter=False)
        
        df3 = pd.merge(df1, df2, on=i['concat']['key'], how=i['concat']['how'])
        
        if not len(i['output_file']['columns']) == 0:
            df3 = df3[i['output_file']['columns']]

        if i['output_file']['file_name'] == '':
            output_file = i['input_file']['file_name1']
        else:
            output_file = i['output_file']['file_name']

        df3.to_csv(os.path.join('..', 'output', output_file), index=False)
        with open(os.path.join('..', 'output', 'result_' + output_file + '.txt'), mode='w') as f:
            f.write(output_file + 'の情報\n\n')
            f.write('  ●処理完了日時：' + str(get_time()) + '\n\n')
            f.write('  ●レコード数：' + str(len(df3)) + '\n\n')
            f.write('  ●結合ファイル：' + i['input_file']['file_name1'] + '\n')
            f.write('                  ' + i['input_file']['file_name2'] + '\n')
            f.write('\n')
            f.write('  ●結合条件：' + i['concat']['how'] + '\n\n')
            f.write('  ●カラム：\n')
            for j in df3.columns:
                f.write('            ' + j + '\n')
        
        finish_join_cnt = finish_join_cnt + 1
        add_log(str(finish_join_cnt) +  "/" +  str(all_join_cnt) + "件の結合を完了")


if __name__ == '__main__':
    main()
    